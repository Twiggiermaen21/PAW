<?php
/* Smarty version 4.3.4, created on 2024-06-03 11:38:41
  from 'C:\xampp\htdocs\studia\LAB9\app\views\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_665d8f2114d1f4_35707752',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '39b9ac356fcec9a0dd1eae46125a786905f08257' => 
    array (
      0 => 'C:\\xampp\\htdocs\\studia\\LAB9\\app\\views\\index.tpl',
      1 => 1717407432,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.tpl' => 1,
    'file:MainBookList.tpl' => 1,
  ),
),false)) {
function content_665d8f2114d1f4_35707752 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2028154493665d8f211364e1_33791202', 'glowna');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'glowna'} */
class Block_2028154493665d8f211364e1_33791202 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'glowna' => 
  array (
    0 => 'Block_2028154493665d8f211364e1_33791202',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<div id="main">
		<div class="inner">
			<header>
				<h1>Kupuj, wypożyczaj i czytaj książki, które lubisz.<br /></h1>
				<form id="search-form" class="pure-form pure-form-stacked"
					onsubmit="ajaxPostForm('search-form','<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
StronaGlownaBookList','table'); return false;">
					<div class="row">
						<div class="col-6 col-12-xsmall">
							<label>
								<h2>Opcje wyszukiwania</h2>
							</label>
							<input type="text" placeholder="Tytul" name="sf_searchForm"
								value="<?php echo $_smarty_tpl->tpl_vars['searchForm']->value->search;?>
" /><br />
						</div>
					</div>
					<button type="submit" class="button primary">Filtruj</button>
				</form>
				<?php $_smarty_tpl->_subTemplateRender('file:messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
			</header>

			<div id="table">
				<?php $_smarty_tpl->_subTemplateRender("file:MainBookList.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
			</div>

			<br><br><br><br><br>

			<div style="text-align: center">
				<a class="pure-button pure-button-active" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
StronaGlowna?page=1"> First</a>
				<?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['searchForm']->value->all+1 - (1) : 1-($_smarty_tpl->tpl_vars['searchForm']->value->all)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 1, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration === 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration === $_smarty_tpl->tpl_vars['i']->total;?>
					<?php if ($_smarty_tpl->tpl_vars['i']->value > $_smarty_tpl->tpl_vars['searchForm']->value->page-2 && $_smarty_tpl->tpl_vars['i']->value <= $_smarty_tpl->tpl_vars['searchForm']->value->page+3) {?>
						<a id="ButtonI" class="pure-button pure-button-active"
						href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
StronaGlowna?page=<?php echo $_smarty_tpl->tpl_vars['i']->value;?>
&sf_searchForm=<?php echo $_smarty_tpl->tpl_vars['searchForm']->value->search;?>
">
							<?php echo $_smarty_tpl->tpl_vars['i']->value;?>
 </a>
					<?php }?>
				<?php }
}
?>
				<a class="pure-button pure-button-active"
				href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
StronaGlowna?page=<?php echo $_smarty_tpl->tpl_vars['searchForm']->value->all;?>
&sf_searchForm=<?php echo $_smarty_tpl->tpl_vars['searchForm']->value->search;?>
">
					Last
				</a>
			</div>
		</div>
	</div>
<?php
}
}
/* {/block 'glowna'} */
}
