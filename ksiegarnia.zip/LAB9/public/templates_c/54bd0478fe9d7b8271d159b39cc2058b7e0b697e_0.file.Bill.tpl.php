<?php
/* Smarty version 4.3.4, created on 2024-05-19 14:32:19
  from 'C:\xampp\htdocs\studia\LAB9\app\views\Bill.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6649f15392aed0_05948229',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '54bd0478fe9d7b8271d159b39cc2058b7e0b697e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\studia\\LAB9\\app\\views\\Bill.tpl',
      1 => 1716121808,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.tpl' => 1,
  ),
),false)) {
function content_6649f15392aed0_05948229 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18524885996649f153910112_68126696', 'glowna');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'glowna'} */
class Block_18524885996649f153910112_68126696 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'glowna' => 
  array (
    0 => 'Block_18524885996649f153910112_68126696',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <div id="main">
        <div class="inner">
            <header>
                <h1>Adres dostawy i rodzaj płatności<br /></h1>
                <?php $_smarty_tpl->_subTemplateRender('file:messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
            </header>
            <section>
                <div style="width:90%; margin: 2em auto;">
                    <div class="row gtr-uniform">
                        <div class="col-6 col-12-xsmall"> </div>
                        <div class="col-6 col-12-xsmall" style="text-align:right"> <?php echo $_smarty_tpl->tpl_vars['pay']->value->Data;?>
 </div>
                        <div class="col-6 col-12-xsmall">Sprzedawca <br> <a>Ksiegarnia </a> </div>
                        <div class="col-6 col-12-xsmall"> Nabywca <br> <a><?php echo $_smarty_tpl->tpl_vars['user']->value->Imie;?>
 <?php echo $_smarty_tpl->tpl_vars['user']->value->Nazwisko;?>
 </a> <br> <a><?php echo $_smarty_tpl->tpl_vars['user']->value->login;?>
 </a> </div>
                        <div class="col-12 col-12-xsmall">
                            <div class="table-wrapper">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Książka</th>
                                            <th>Autor</th>
                                            <th>Sztuk</th>
                                            <th>Cena</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['Order']->value->book, 'b');
$_smarty_tpl->tpl_vars['b']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['b']->value) {
$_smarty_tpl->tpl_vars['b']->do_else = false;
?>
                                            <tr>
                                                <td> <?php echo $_smarty_tpl->tpl_vars['b']->value['Tytul'];?>
</td>
                                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['Order']->value->autor, 'a');
$_smarty_tpl->tpl_vars['a']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['a']->value) {
$_smarty_tpl->tpl_vars['a']->do_else = false;
?>
                                                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['Order']->value->autor_book, 'ab');
$_smarty_tpl->tpl_vars['ab']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['ab']->value) {
$_smarty_tpl->tpl_vars['ab']->do_else = false;
?>
                                                        <?php if ($_smarty_tpl->tpl_vars['b']->value['idKsiazki'] == $_smarty_tpl->tpl_vars['ab']->value['Ksiazki_idKsiazki'] && $_smarty_tpl->tpl_vars['a']->value['idAutor_Ksiazki'] == $_smarty_tpl->tpl_vars['ab']->value['Autor_Ksiazki_idAutor_Ksiazki']) {?>
                                                            <td> <?php echo $_smarty_tpl->tpl_vars['a']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['a']->value['Nazwisko'];?>
</td>
                                                        <?php }?>
                                                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                                <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['Order']->value->sztuk+1 - (0) : 0-($_smarty_tpl->tpl_vars['Order']->value->sztuk)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 0, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration === 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration === $_smarty_tpl->tpl_vars['i']->total;?>
                                                    <?php if ($_smarty_tpl->tpl_vars['b']->value['idKsiazki'] == $_smarty_tpl->tpl_vars['Order']->value->tablica[0][$_smarty_tpl->tpl_vars['i']->value]) {?>
                                                        <td><?php echo $_smarty_tpl->tpl_vars['Order']->value->tablica[1][$_smarty_tpl->tpl_vars['i']->value];?>
</td>
                                                    <?php }?>
                                                <?php }
}
?>
                                                <td><?php echo $_smarty_tpl->tpl_vars['b']->value['Cena'];?>
</td>
                                            </tr>
                                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="3"></td>
                                            <td>
                                                <?php echo $_smarty_tpl->tpl_vars['Order']->value->cena;?>
</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                    Sposób zapłaty: <?php echo $_smarty_tpl->tpl_vars['pay']->value->Pay;?>
 <br>
                    Adres: <?php echo $_smarty_tpl->tpl_vars['pay']->value->Adres;?>

                </div>
        </section>
    </div>
    </div>
<?php
}
}
/* {/block 'glowna'} */
}
