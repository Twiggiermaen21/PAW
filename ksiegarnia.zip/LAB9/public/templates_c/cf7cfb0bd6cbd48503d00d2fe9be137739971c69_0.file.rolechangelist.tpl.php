<?php
/* Smarty version 4.3.4, created on 2024-06-03 15:30:13
  from 'C:\xampp\htdocs\studia\LAB9\app\views\rolechangelist.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_665dc5655ff621_37176026',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cf7cfb0bd6cbd48503d00d2fe9be137739971c69' => 
    array (
      0 => 'C:\\xampp\\htdocs\\studia\\LAB9\\app\\views\\rolechangelist.tpl',
      1 => 1717421378,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_665dc5655ff621_37176026 (Smarty_Internal_Template $_smarty_tpl) {
?><table id="User_tab" class="pure-table pure-table-bordered">
    <tbody>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['dane']->value, 'd');
$_smarty_tpl->tpl_vars['d']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->do_else = false;
?>
            <tr><th>imię</th><td><?php echo $_smarty_tpl->tpl_vars['d']->value["Imie"];?>
</td></tr><tr><th>Nazwisko</th><td><?php echo $_smarty_tpl->tpl_vars['d']->value["Nazwisko"];?>
</td></tr><tr><th>Email</th><td><?php echo $_smarty_tpl->tpl_vars['d']->value["Email"];?>
</td></tr><tr><th>Hasło</th><td><?php echo $_smarty_tpl->tpl_vars['d']->value["Haslo"];?>
</td></tr><tr><th>Role</th><td><?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['dane_role']->value, 'dr');
$_smarty_tpl->tpl_vars['dr']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['dr']->value) {
$_smarty_tpl->tpl_vars['dr']->do_else = false;
ob_start();
echo $_smarty_tpl->tpl_vars['d']->value["idUzytkownik"];
$_prefixVariable1 = ob_get_clean();
if ($_smarty_tpl->tpl_vars['dr']->value["Uzytkownik_idUzytkownik"] == $_prefixVariable1) {
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['role']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
if ($_smarty_tpl->tpl_vars['r']->value["idRola"] == $_smarty_tpl->tpl_vars['dr']->value["Rola_idRola"]) {
echo $_smarty_tpl->tpl_vars['r']->value["NazwaRoli"];?>
<br><?php }
ob_start();
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
$_prefixVariable2 = ob_get_clean();
echo $_prefixVariable2;
}
ob_start();
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
$_prefixVariable3 = ob_get_clean();
echo $_prefixVariable3;?>
</td></tr><tr><th>Data_aktualizacji</th><td><?php echo $_smarty_tpl->tpl_vars['d']->value["Data_aktualizacji"];?>
</td></tr><tr><th>Id_aktualizacji</th><td><?php echo $_smarty_tpl->tpl_vars['d']->value["Id_aktualizacji"];?>
</td></tr><tr><th>aktywny</th><td><?php if ($_smarty_tpl->tpl_vars['d']->value["aktywny"] == 1) {?>YES<?php } else { ?> NO<?php }?></td></tr><tr><td> <a class="button primary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
personEdit?id=<?php echo $_smarty_tpl->tpl_vars['d']->value['idUzytkownik'];?>
">Edytuj</a></td><td> <a class="button primary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
personDelete?id=<?php echo $_smarty_tpl->tpl_vars['d']->value['idUzytkownik'];?>
">Usuń</a></td></tr>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </tbody>
</table><?php }
}
