<?php
/* Smarty version 4.3.4, created on 2024-05-19 14:51:07
  from 'C:\xampp\htdocs\studia\LAB9\app\views\BookPage.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6649f5bb1bfa62_20778771',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0171c09ea178aaa844bf3b0a0ef85f3926b8654d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\studia\\LAB9\\app\\views\\BookPage.tpl',
      1 => 1716123010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6649f5bb1bfa62_20778771 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20427580336649f5bb1b5469_32890715', 'glowna');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'glowna'} */
class Block_20427580336649f5bb1b5469_32890715 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'glowna' => 
  array (
    0 => 'Block_20427580336649f5bb1b5469_32890715',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


	<!-- Main -->
	<div id="main">
		<div class="inner">
			<section>

				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['book']->value, 'b');
$_smarty_tpl->tpl_vars['b']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['b']->value) {
$_smarty_tpl->tpl_vars['b']->do_else = false;
?>
					<div class="row gtr-uniform">
						<div class="col-6 col-12-xsmall">

							<span class="image fit">
								<img src="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/<?php echo $_smarty_tpl->tpl_vars['b']->value["img_url"];?>
" />
							</span>
						</div>
						<div class="col-6 col-12-xsmall">

							<h1> <?php echo $_smarty_tpl->tpl_vars['b']->value["Tytul"];?>
 </h1>
							<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
AddBookKoszyk?book=<?php echo $_smarty_tpl->tpl_vars['b']->value["idKsiazki"];?>
">
								


								<ul class="actions fit">
								<li><input type="submit" class="button primary" value="Kup" /></li>
								<li><div class="button"><input type="text" name="Ilosc" id="Ilosc" value="1" placeholder="Ilość " /></div></li>
								

							</ul>


							</form>

							<div class="table-wrapper">
								<table class="alt">
									<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['autor']->value, 'a');
$_smarty_tpl->tpl_vars['a']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['a']->value) {
$_smarty_tpl->tpl_vars['a']->do_else = false;
?>
										<tbody>
											<tr>
												<td>Autor</td>
												<td><?php echo $_smarty_tpl->tpl_vars['a']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['a']->value['Nazwisko'];?>
</td>

											</tr>
											<tr>
												<td>Kraj Pochodzenia</td>
												<td><?php echo $_smarty_tpl->tpl_vars['a']->value['Kraj_pochodzenia'];?>
</td>

											</tr>
											<tr>
												<td>Data Urodzenia Autora</td>
												<td> <?php echo $_smarty_tpl->tpl_vars['a']->value['Data_urodzenia'];?>
</td>

											</tr>
										<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
										<tr>
											<td>Cena</td>
											<td><?php echo $_smarty_tpl->tpl_vars['b']->value["Cena"];?>
 zł</td>

										</tr>
										<tr>
											<td>Ilość Stron</td>
											<td><?php echo $_smarty_tpl->tpl_vars['b']->value["Ilosc_stron"];?>
</td>

										</tr>

									</tbody>

								</table>
							</div>

							Opis
							<br>
							<?php echo $_smarty_tpl->tpl_vars['b']->value["Opis"];?>




						</div>


					</div>
				<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>



			</section>
		</div>
	</div>

<?php
}
}
/* {/block 'glowna'} */
}
