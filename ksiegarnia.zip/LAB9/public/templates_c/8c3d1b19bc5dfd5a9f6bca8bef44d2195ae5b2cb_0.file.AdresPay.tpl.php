<?php
/* Smarty version 4.3.4, created on 2024-05-21 10:55:27
  from 'C:\xampp\htdocs\studia\LAB9\app\views\AdresPay.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_664c617f87ba78_36907451',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8c3d1b19bc5dfd5a9f6bca8bef44d2195ae5b2cb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\studia\\LAB9\\app\\views\\AdresPay.tpl',
      1 => 1716281725,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.tpl' => 1,
  ),
),false)) {
function content_664c617f87ba78_36907451 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_362617756664c617f8700d2_31036185', 'glowna');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'glowna'} */
class Block_362617756664c617f8700d2_31036185 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'glowna' => 
  array (
    0 => 'Block_362617756664c617f8700d2_31036185',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <div id="main">
        <div class="inner">
            <header>
                <h1>Adres dostawy i rodzaj płatności<br /></h1>
                <?php $_smarty_tpl->_subTemplateRender('file:messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

            </header>
            <section>
                <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
OrderComplete">
                    <div class="row gtr-uniform">
                        <div class="col-6 col-12-xsmall">
                            <label for="Adres">Podaj Adres</label>

                            <input type="text" name="Adres" id="Adres" value="<?php echo $_smarty_tpl->tpl_vars['pay']->value->Adres;?>
"
                                placeholder="np. Drogowa 13 Warszawa 21-231" />
                            <br>
                            <label for="pay">Wybierz rodzaj płatności</label>


                            <div class="col-4 col-12-small">
                                <input type="radio" id="Przelew" name="pay" value="Przelew Bankowy"
                                    <?php if ($_smarty_tpl->tpl_vars['pay']->value->Pay == "Przelew Bankowy") {?> checked <?php }?>>
                                <label for="Przelew">Przelew Bankowy</label>
                            </div>
                            <div class="col-4 col-12-small">
                                <input type="radio" id="Blik" name="pay" value="Blik" <?php if ($_smarty_tpl->tpl_vars['pay']->value->Pay == "Blik") {?> checked
                                    <?php }?>>
                                <label for="Blik">Blik</label>
                            </div>



                            <div class="col-4 col-12-small">
                                <input type="radio" id="Gotowka" name="pay" value="Gotowka" <?php if ($_smarty_tpl->tpl_vars['pay']->value->Pay == "Gotowka") {?>
                                    checked <?php }?>>
                                <label for="Gotowka">Gotówka</label>
                            </div>

                            <div class="col-6 col-12-small">
                                <input type="checkbox" id="regulamin" name="regulamin">
                                <label for="regulamin">Akceptuje regulami płatności i dostawy</label>
                            </div>


                        </div>

                        <div class="col-12">
                            <ul class="actions">
                                <li><input type="submit" name="submit " value="Zrealizuj zamównienie" class="primary" />
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </section>
        </div>
    </div>
<?php
}
}
/* {/block 'glowna'} */
}
