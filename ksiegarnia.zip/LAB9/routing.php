<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('StronaGlowna');
App::getRouter()->setLoginRoute('login');

Utils::addRoute('StronaGlowna', 'main');
Utils::addRoute('StronaGlownaBookList', 'main');



Utils::addRoute('BookShow', 'BookPage');
Utils::addRoute('wiadomosci', 'main');
Utils::addRoute('loginShow',    'LoginCtrl');
Utils::addRoute('login',  'LoginCtrl');
Utils::addRoute('register',  'RegisterCtrl');
Utils::addRoute('registerShow',  'RegisterCtrl');
Utils::addRoute('logout',    'LoginCtrl');


Utils::addRoute('BookAddShow', 'BookPage', ['Pracownik']);
Utils::addRoute('BookAdd', 'BookPage', [ 'Pracownik']);
Utils::addRoute('AutorAdd', 'AutorPage', [ 'Pracownik']);
Utils::addRoute('AutorAddShow', 'AutorPage', [ 'Pracownik']);




Utils::addRoute('Showbill',    'Bill', ['Kupujacy']);

Utils::addRoute('KoszykShow',    'Koszyk', ['Kupujacy']);

Utils::addRoute('Ordertrasfer', 'Koszyk', ['Kupujacy']);
Utils::addRoute('ErrorPay', 'Koszyk', ['Kupujacy']);
Utils::addRoute('PayAdres', 'Bill', ['Kupujacy']);
Utils::addRoute('KoszykClear', 'Koszyk', ['Kupujacy']);
Utils::addRoute('AddBookKoszyk', 'Koszyk', ['Kupujacy']);
Utils::addRoute('OrderComplete', 'Bill', ['Kupujacy']);
Utils::addRoute('UserDataShow', 'Userdata', ['Kupujacy']);



Utils::addRoute('RoleShow', 'RoleChange', ['Admin']);
Utils::addRoute('RoleShowlist', 'RoleChange', ['Admin']);
Utils::addRoute('admin_role_addShow', 'PersonEditCtrl', ['Admin']);

Utils::addRoute('admin_role_add', 'PersonEditCtrl', ['Admin']);
Utils::addRoute('admin_role_delete', 'PersonEditCtrl', ['Admin']);

Utils::addRoute('personEdit', 'PersonEditCtrl', ['Kupujacy']);
Utils::addRoute('personSave', 'PersonEditCtrl', ['Kupujacy']);
Utils::addRoute('personDelete', 'PersonEditCtrl', ['Admin']);
