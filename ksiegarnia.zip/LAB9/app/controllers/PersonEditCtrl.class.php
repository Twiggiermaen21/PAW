<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\PersonEditForm;

class PersonEditCtrl
{
    private $form;
    private $v;
    public function __construct()
    {
        $this->v = new Validator();
        $this->form = new PersonEditForm();
    }

    public function validateSave()
    {
        $this->form->id = ParamUtils::getFromPost('id', true, 'Błędne wywołanie aplikacji');
        if (in_array('Admin', unserialize($_SESSION['user'])->role)) {
            $role = ParamUtils::getFromPost('role', true, 'Błędne wywołanie aplikacji');
        }

        $this->form->Imie = $this->v->validateFromPost('name', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj imię',
            'min_length' => 2,
            'max_length' => 20,
            'validator_message' => 'Imię powinno mieć od 2 do 20 znaków'
        ]);
        $this->form->Nazwisko = $this->v->validateFromPost('Nazwisko', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj nazwisko',
            'min_length' => 2,
            'max_length' => 20,
            'validator_message' => 'Nazwisko powinno mieć od 2 do 20 znaków'
        ]);
        $this->form->Email = $this->v->validateFromPost('Email', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj Email',
            'min_length' => 2,
            'max_length' => 100,
            'email' => true,
            'validator_message' => 'Zły format Email'
        ]);
        $this->form->Haslo = $this->v->validateFromPost('Haslo', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj Haslo',
            'min_length' => 10,
            'max_length' => 20,
            'validator_message' => 'Hasło powinno mieć od 10 do 20 znaków'
        ]);
        $this->form->Data_aktualizacji = date('Y-m-d H:i:s');
        $this->form->Id_aktualizacji = $this->form->id;
        $Rols = array();

        if (in_array('Admin', unserialize($_SESSION['user'])->role)) {
            $i = 0;



            $Rola_idRola = App::getDB()->select(
                "uzytkownik_has_rola",
                'Rola_idRola',
                ['Uzytkownik_idUzytkownik' => $this->form->id]
            );
 
            $rols = array();
            $i = 0;
            foreach ($Rola_idRola as $r) {
                $role = App::getDB()->get(
                    "rola",
                    "NazwaRoli",
                    ["IdRola" => $r]
                );
                $rols[$i] = $role;
                $i++;
            }
            $j = 0;
            foreach ($Rola_idRola as $r) {
                $Rols[$j] = $this->v->validateFromPost($rols[$j], [
                    'trim' => true,
                    'required' => true,
                    'required_message' => 'Podaj role',
                    'min_length' => 1,
                    'max_length' => 10,
                    'validator_message' => 'Hasło powinno mieć od 1 do 5 znaków'
                ]);
                $j++;
            }

            if (!(sizeof($Rols) == sizeof(array_unique($Rols)))) {
                Utils::addErrorMessage('Zła rola');
            } else {
                $this->form->Role = $Rols;
            }
            foreach ($Rols as $r) {
                if (!($r == 'Admin' ||  $r == 'Kupujacy' || $r == 'Pracownik')) {
                    Utils::addErrorMessage('Zła rola');
                }
            }
        }
        return !App::getMessages()->isError();
    }

    public function validateEdit()
    {
        $this->form->id = $_GET['id'];
        return !App::getMessages()->isError();
    }

    public function action_personNew()
    {
        $this->generateView();
    }

    public function action_personEdit()
    {

        if ($this->validateEdit()) {
            try {

                $record = App::getDB()->get("uzytkownik", "*", [
                    "idUzytkownik" => $this->form->id
                ]);


                $Rola_idRola = App::getDB()->select(
                    "uzytkownik_has_rola",
                    'Rola_idRola',
                    ['Uzytkownik_idUzytkownik' => $this->form->id]
                );

                $role = App::getDB()->get(
                    "rola",
                    "NazwaRoli",
                    ["IdRola" => $Rola_idRola]
                );


                $rols = array();
                $i = 0;
                foreach ($Rola_idRola as $r) {
                    $role = App::getDB()->get(
                        "rola",
                        "NazwaRoli",
                        ["IdRola" => $r]
                    );
                    $rols[$i] = $role;
                    $i++;
                }

                $this->form->Role = $rols;
                $this->form->aktywny = $record['aktywny'];
                $this->form->id = $record['idUzytkownik'];
                $this->form->Imie = $record['Imie'];
                $this->form->Nazwisko = $record['Nazwisko'];
                $this->form->Email = $record['Email'];
                $this->form->Data_aktualizacji = $record['Data_aktualizacji'];
                $this->form->Haslo = $record['Haslo'];
                $this->form->Id_aktualizacji = $record['Id_aktualizacji'];
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas edytu rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }
        $this->generateView();
    }

    public function action_personDelete()
    {
        if ($this->validateEdit()) {
            try {

                App::getDB()->update(
                    "uzytkownik",
                    ["aktywny" => 0],
                    ["idUzytkownik" => $this->form->id]
                );
                Utils::addInfoMessage('Pomyślnie usunięto rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }
        App::getRouter()->forwardTo('RoleShow');
    }

    public function action_admin_role_delete()
    {

        $rola = $_GET['rola'];
        $id = $_GET['id'];

        $IDrole = App::getDB()->get(
            "rola",
            "IdRola",
            ["NazwaRoli" => $rola]
        );

        try {

            App::getDB()->delete(
                "uzytkownik_has_rola",

                [
                    "Rola_idRola" => $IDrole,
                    'Uzytkownik_idUzytkownik' => $id

                ]
            );
            Utils::addInfoMessage('Pomyślnie usunięto role');
        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas usuwania roli');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }

        App::getRouter()->forwardTo('RoleShow');
    }

    public function action_admin_role_addShow()
    {
        App::getSmarty()->assign('rola', "");

        App::getSmarty()->assign('id', $_GET['id']);
        App::getSmarty()->display('RoleAddShow.tpl');
    }

    public function action_admin_role_add()
    {
        $id = ParamUtils::getFromPost('id', true, 'Błędne wywołanie aplikacji');
        $rola = $this->v->validateFromPost('rola', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj role',
            'min_length' => 2,
            'max_length' => 20,
            'validator_message' => 'Rola powinno mieć od 2 do 10 znaków'
        ]);
        if (!($rola == 'Admin' ||  $rola == 'Kupujacy' || $rola == 'Pracownik')) {
            Utils::addErrorMessage('Zła rola');
        }else{

        
        try {
            $IdRole = App::getDB()->get(
                "rola",
                "IdRola",
                ["NazwaRoli" => $rola]
            );
            App::getDB()->insert("uzytkownik_has_rola", [
                "Data_nadania" =>  date('Y-m-d H:i:s'),
                "Rola_idRola" => $IdRole,
                "Uzytkownik_idUzytkownik" => $id

            ]);
            Utils::addInfoMessage('Pomyślnie dodano role');
        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas dodawania rekordu');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }
    }
if( !App::getMessages()->isError()){
    App::getRouter()->forwardTo('RoleShow');
}else {
    App::getSmarty()->assign('rola', $rola);
    App::getSmarty()->assign('id', $id);

    App::getSmarty()->display('RoleAddShow.tpl');

}
    
    }
    public function admin_Role()
    {
        try {
            $idUzytkownik_has_Rola = App::getDB()->select(
                "uzytkownik_has_rola",
                'idUzytkownik_has_Rola',
                ['Uzytkownik_idUzytkownik' => $this->form->id]
            );

            for ($i = 0; $i < 2; $i++) {

                App::getDB()->update(
                    "uzytkownik_has_rola",
                    [
                        "Rola_idRola" => App::getDB()->get("rola", "idRola", [
                            "NazwaRoli" => $this->form->Role[$i]
                        ])
                    ],
                    [
                        "Uzytkownik_idUzytkownik" => $this->form->id,
                        "idUzytkownik_has_Rola" => $idUzytkownik_has_Rola[$i]
                    ]
                );
            }

            Utils::addInfoMessage('Pomyślnie zaktualizowano role');
        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas aktualizacji rekordu');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }
    }

    public function action_personSave()
    {
        if ($this->validateSave()) {

            try {
                App::getDB()->update("uzytkownik", [
                    "Imie" => $this->form->Imie,
                    "Nazwisko" => $this->form->Nazwisko,
                    "Email" => $this->form->Email,
                    "Data_aktualizacji" => $this->form->Data_aktualizacji,
                    "Id_aktualizacji" => unserialize($_SESSION['user'])->id,
                    "Haslo" => $this->form->Haslo
                ], [
                    "idUzytkownik" => $this->form->id
                ]);

                if (in_array('Admin', unserialize($_SESSION['user'])->role)) {
                    $this->admin_Role();
                }

                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }

            if (in_array('Admin', unserialize($_SESSION['user'])->role)) {
                App::getRouter()->forwardTo('RoleShow');
            } else {
                App::getRouter()->forwardTo('StronaGlowna');
            }
        } else {
            $this->generateView();
        }
    }

    public function generateView()
    {
        App::getSmarty()->assign('user', unserialize($_SESSION['user']));
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->display('PersonEdit.tpl');
    }
}
