<?php

namespace app\forms;

class BookForm
{
	public $Tytul;
	public $Autor;
	public $Opis;
	public $Cena;
	public $Ilosc_stron;
}
