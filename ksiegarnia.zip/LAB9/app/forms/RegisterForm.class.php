<?php

namespace app\forms;

class RegisterForm
{
    public $Imie;
    public $Nazwisko;
    public $Data_urodzenia;
    public $Adres;
    public $Email;
    public $Data_aktualizacji;
    public $Id_aktualizacji;
    public $Haslo;
    public $Haslo2;
}
