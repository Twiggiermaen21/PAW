<?php

namespace app\forms;

class PayForm
{
	public $Adres;
	public $Pay;
	public $Regulamin;
	public $Data;
}
