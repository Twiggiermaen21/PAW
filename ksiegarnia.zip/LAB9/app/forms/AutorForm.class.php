<?php

namespace app\forms;

class AutorForm
{
	public $Imie;
	public $Nazwisko;
	public $Data_urodzenia;
	public $Kraj_pochodzenia;
}
