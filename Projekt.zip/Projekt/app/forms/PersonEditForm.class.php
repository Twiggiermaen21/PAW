<?php

namespace app\forms;

class PersonEditForm
{
	public $id;
	public $Imie;
	public $Nazwisko;
	public $Data_urodzenia;
	public $Adres;
	public $Data_aktualizacji;
	public $Id_aktualizacji;
	public $Email;
	public $Haslo;
	public $aktywny;
	public $Role=array();
}
