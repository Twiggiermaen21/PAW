<?php

namespace app\forms;

class BookListForm
{
	public $search;
	public $count;
	public $from;
	public $all;
	public $page;
	public $limit;
}
