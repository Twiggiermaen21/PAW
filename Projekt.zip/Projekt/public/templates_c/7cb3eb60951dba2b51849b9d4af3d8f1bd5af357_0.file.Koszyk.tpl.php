<?php
/* Smarty version 4.3.4, created on 2024-05-17 19:29:55
  from 'C:\xampp\htdocs\studia\LAB9\app\views\Koszyk.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_664794139a8455_03466221',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7cb3eb60951dba2b51849b9d4af3d8f1bd5af357' => 
    array (
      0 => 'C:\\xampp\\htdocs\\studia\\LAB9\\app\\views\\Koszyk.tpl',
      1 => 1715966961,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.tpl' => 1,
  ),
),false)) {
function content_664794139a8455_03466221 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_45062286066479413999d21_65946235', 'glowna');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'glowna'} */
class Block_45062286066479413999d21_65946235 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'glowna' => 
  array (
    0 => 'Block_45062286066479413999d21_65946235',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<!-- Main -->
	<div id="main">
		<div class="inner">
			<header>
				<h1>Twój Koszyk<br /></h1>
				<?php $_smarty_tpl->_subTemplateRender('file:messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
			</header>
			<div style="width:90%; margin: 2em auto;">
				<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Ordertrasfer" method="post" class="pure-form pure-form-aligned">
					<div class="table-wrapper">
						<table>
							<thead>
								<tr>
									<th>Książka</th>
									<th>Autor</th>
									<th>Sztuk</th>
									<th>Cena</th>
								</tr>
							</thead>
							<tbody>
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['book']->value, 'b');
$_smarty_tpl->tpl_vars['b']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['b']->value) {
$_smarty_tpl->tpl_vars['b']->do_else = false;
?>
									<tr>
										<td> <?php echo $_smarty_tpl->tpl_vars['b']->value['Tytul'];?>
</td>
										<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['autor']->value, 'a');
$_smarty_tpl->tpl_vars['a']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['a']->value) {
$_smarty_tpl->tpl_vars['a']->do_else = false;
?>
											<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['autor_book']->value, 'ab');
$_smarty_tpl->tpl_vars['ab']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['ab']->value) {
$_smarty_tpl->tpl_vars['ab']->do_else = false;
?>
												<?php if ($_smarty_tpl->tpl_vars['b']->value['idKsiazki'] == $_smarty_tpl->tpl_vars['ab']->value['Ksiazki_idKsiazki'] && $_smarty_tpl->tpl_vars['a']->value['idAutor_Ksiazki'] == $_smarty_tpl->tpl_vars['ab']->value['Autor_Ksiazki_idAutor_Ksiazki']) {?>
													<td> <?php echo $_smarty_tpl->tpl_vars['a']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['a']->value['Nazwisko'];?>
</td>
												<?php }?>
											<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
										<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
										<?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['Ilosc']->value+1 - (0) : 0-($_smarty_tpl->tpl_vars['Ilosc']->value)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 0, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration === 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration === $_smarty_tpl->tpl_vars['i']->total;?>
											<?php if ($_smarty_tpl->tpl_vars['b']->value['idKsiazki'] == $_smarty_tpl->tpl_vars['tablica']->value[0][$_smarty_tpl->tpl_vars['i']->value]) {?>
												<td><?php echo $_smarty_tpl->tpl_vars['tablica']->value[1][$_smarty_tpl->tpl_vars['i']->value];?>
</td>
											<?php }?>
										<?php }
}
?>
										<td><?php echo $_smarty_tpl->tpl_vars['b']->value['Cena'];?>
</td>
									</tr>
								<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
							</tbody>
							<tfoot>
								<tr>
									<td colspan="3"></td>
									<td>
										<?php echo $_smarty_tpl->tpl_vars['cena']->value;?>
</td>
								</tr>
							</tfoot>
						</table>
					</div>
					<input type="submit" class="pure-button pure-button-primary" value="Płatność i dostawa" />
				</form>
				<a class="button primary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
KoszykClear">Wyczyść Koszyk</a>
			</div>
		</div>
	</div>
<?php
}
}
/* {/block 'glowna'} */
}
