<?php
/* Smarty version 4.3.4, created on 2024-06-03 17:29:27
  from 'C:\xampp\htdocs\studia\LAB9\app\views\RoleAddShow.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_665de157c067f7_63029413',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '250e05c5a8dd76d53f9a839d0025dc2f555c2bfa' => 
    array (
      0 => 'C:\\xampp\\htdocs\\studia\\LAB9\\app\\views\\RoleAddShow.tpl',
      1 => 1717428548,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.tpl' => 1,
  ),
),false)) {
function content_665de157c067f7_63029413 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1130796187665de157c001c7_61427822', 'glowna');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'glowna'} */
class Block_1130796187665de157c001c7_61427822 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'glowna' => 
  array (
    0 => 'Block_1130796187665de157c001c7_61427822',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <div id="main">
        <div class="inner">

            <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
admin_role_add" method="post" class="pure-form pure-form-aligned">
                <div class="row">
                    <div class="col-6 col-12-xsmall">
                    <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">

                        <input type="text" name="rola" value="<?php echo $_smarty_tpl->tpl_vars['rola']->value;?>
" /><br />
                    </div>
                </div>
                <button type="submit" class="button primary">Dodaj</button>
            </form>
            <?php $_smarty_tpl->_subTemplateRender('file:messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        </div>
    </div>
    </div>
<?php
}
}
/* {/block 'glowna'} */
}
