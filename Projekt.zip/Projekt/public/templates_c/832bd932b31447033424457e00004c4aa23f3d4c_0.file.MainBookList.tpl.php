<?php
/* Smarty version 4.3.4, created on 2024-06-03 17:37:38
  from 'C:\xampp\htdocs\studia\LAB9\app\views\MainBookList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_665de342578a59_03564512',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '832bd932b31447033424457e00004c4aa23f3d4c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\studia\\LAB9\\app\\views\\MainBookList.tpl',
      1 => 1717429056,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_665de342578a59_03564512 (Smarty_Internal_Template $_smarty_tpl) {
?><section class="tiles">
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['records']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?>
					<article><div class="image"><img src="<?php echo $_smarty_tpl->tpl_vars['r']->value["img_url"];?>
"  /></div><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
BookShow?book=<?php echo $_smarty_tpl->tpl_vars['r']->value["idKsiazki"];?>
"><div class="content"><p>Tytuł: <?php echo $_smarty_tpl->tpl_vars['r']->value["Tytul"];?>
</p><p>Cena: <?php echo $_smarty_tpl->tpl_vars['r']->value["Cena"];?>
</p><p>Ilosc stron: <?php echo $_smarty_tpl->tpl_vars['r']->value["Ilosc_stron"];?>
</p><p>Opis: <?php echo $_smarty_tpl->tpl_vars['r']->value["Opis"];?>
</p></div></a></article>
				<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

				
			</section><?php }
}
