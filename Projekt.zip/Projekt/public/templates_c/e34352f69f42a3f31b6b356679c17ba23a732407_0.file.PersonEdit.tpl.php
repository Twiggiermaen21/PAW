<?php
/* Smarty version 4.3.4, created on 2024-06-03 17:13:25
  from 'C:\xampp\htdocs\studia\LAB9\app\views\PersonEdit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_665ddd95551c72_01498496',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e34352f69f42a3f31b6b356679c17ba23a732407' => 
    array (
      0 => 'C:\\xampp\\htdocs\\studia\\LAB9\\app\\views\\PersonEdit.tpl',
      1 => 1717427604,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.tpl' => 1,
  ),
),false)) {
function content_665ddd95551c72_01498496 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1438856651665ddd95542a33_88020140', 'glowna');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'glowna'} */
class Block_1438856651665ddd95542a33_88020140 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'glowna' => 
  array (
    0 => 'Block_1438856651665ddd95542a33_88020140',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div id="main">
        <div class="inner">
            <header>
                <h1>Dane użytkownika<br /></h1>
            </header>
            <div style="width:90%; margin: 2em auto;">
                <table id="User_tab" class="pure-table pure-table-bordered">

                    <tbody>
                        <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
personSave" method="post" class="pure-form pure-form-aligned">
                            <tr><th>imię</th><td><input id="name" type="text" name="name" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->Imie;?>
"></td></tr><tr><th>Nazwisko</th><td> <input id="Nazwisko" type="text" name="Nazwisko" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->Nazwisko;?>
"></td></tr><tr><th>Email</th><td><input id="Email" type="text" name="Email" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->Email;?>
"></td></tr><tr><th>Hasło</th><td><input id="Haslo" type="password" name="Haslo" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->Haslo;?>
"></td></tr><?php if (in_array('Admin',$_smarty_tpl->tpl_vars['user']->value->role)) {?><input type="hidden" name="role" value="<?php echo $_smarty_tpl->tpl_vars['user']->value->role;?>
"><tr><th>Role <br> <br><a class="pure-button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
admin_role_addShow?id=<?php echo $_smarty_tpl->tpl_vars['form']->value->id;?>
">Dodaj</a></th><td><?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['form']->value->Role, 'role');
$_smarty_tpl->tpl_vars['role']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['role']->value) {
$_smarty_tpl->tpl_vars['role']->do_else = false;
?><input id="Rola" type="text" name="<?php echo $_smarty_tpl->tpl_vars['role']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['role']->value;?>
"><a class="pure-button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
admin_role_delete?rola=<?php echo $_smarty_tpl->tpl_vars['role']->value;?>
&id=<?php echo $_smarty_tpl->tpl_vars['form']->value->id;?>
">Usun</a><?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?></td></tr><?php }?><tr><th>Data_aktualizacji</th><td><?php echo $_smarty_tpl->tpl_vars['form']->value->Data_aktualizacji;?>
</td></tr><tr><th>Id_aktualizacji</th><td><?php echo $_smarty_tpl->tpl_vars['form']->value->Id_aktualizacji;?>
</td></tr><tr><th>aktywny</th><td><?php echo $_smarty_tpl->tpl_vars['form']->value->aktywny;?>
</td></tr>

                            <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->id;?>
">
                            <input type="submit" class="pure-button pure-button-primary" value="Zapisz" />
                        </form>
                    </tbody>
                </table>
                <a class="button primary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
personList">Powrót</a>
                </div>
            <?php $_smarty_tpl->_subTemplateRender('file:messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
            </div>
            </div>
<?php
}
}
/* {/block 'glowna'} */
}
